package com.example.room_service.service.impl;


import com.example.room_service.entity.RoomEntity;
import com.example.room_service.repository.RoomRepository;
import com.example.room_service.service.RoomService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    private final RoomRepository roomRepository;

    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @Override
    public RoomEntity createRoom(RoomEntity room) {
        return roomRepository.save(room);
    }

    @Override
    public List<RoomEntity> getAllRooms() {
        return roomRepository.findAll();
    }

    @Override
    public RoomEntity getRoomById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room not found with ID: " + id));
    }

    @Override
    public RoomEntity updateRoom(Long id, RoomEntity roomDetails) {
        RoomEntity room = getRoomById(id);

        room.setDept(roomDetails.getDept());
        room.setCapacity(roomDetails.getCapacity());
        room.setBuildingName(roomDetails.getBuildingName());
        room.setBlock(roomDetails.getBlock());

        return roomRepository.save(room);
    }

    @Override
    public void deleteRoom(Long id) {
        roomRepository.deleteById(id);
    }
}
