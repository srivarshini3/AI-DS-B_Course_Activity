package com.example.college.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;


@Entity
@Table(name = "students")
public class StudentEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long regdId;
	
	@NotBlank(message = "Roll number is required")
	private String rollno;
	
	@NotBlank(message = "Name is required")
	private String name;
	
	@NotBlank(message = "Department is required")
	private String dept;
	
	@NotBlank(message = "Section is required")
	private String section;
	
	@NotBlank(message = "Aadhar is required")
	private String aadharId;
	
	private String skills;
	
	@DecimalMin(value = "0.0", inclusive = true, message = "CGPA must be between 0 and 10")
	@DecimalMax(value = "10.0", inclusive = true, message = "CGPA must be between 0 and 10")
	private Double cgpa;

	
	// Getters and Setters
	public Long getRegdId() {
		return regdId;
	}

	public void setRegdId(Long regdId) {
		this.regdId = regdId;
	}

	public String getRollno() {
		return rollno;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getAadharId() {
		return aadharId;
	}

	public void setAadharId(String aadharId) {
		this.aadharId = aadharId;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public Double getCgpa() {
		return cgpa;
	}

	public void setCgpa(Double cgpa) {
		this.cgpa = cgpa;
	}
	
	
}
